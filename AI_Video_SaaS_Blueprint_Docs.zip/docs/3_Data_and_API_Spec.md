# 数据与 API 规格（Data & API Spec）

## 表（摘要）
- users/teams/team_members
- projects/templates/graphs
- runs/jobs/artifacts
- usage_ledger/billing_payments
- consents/publishing_accounts/publishing_tasks

## 核心 API
- POST /v1/templates/instantiate
- POST /v1/runs · GET /v1/runs/:id/events · GET /v1/runs/:id/artifacts
- GET /v1/billing/credits · POST /v1/billing/creem/webhook
- POST /v1/analyze/link（Strict/Owner）
- POST /v1/publish（多平台草稿/发布）

## SSE 事件（示例）
event: job
data: {"runId":"r1","nodeId":"SCRIPT.LLM","status":"running"}

event: artifact
data: {"jobId":"j3","kind":"video","url":"https://..."}

event: run
data: {"runId":"r1","status":"succeeded","costPoints":83}

## Provider 适配器（TS）
export interface ProviderAdapter {
  call(inputs: Record<string, unknown>, params: Record<string, unknown>, ctx: { signal?: AbortSignal }): Promise<{
    artifact?: { kind: 'video'|'image'|'audio'|'text'|'timeline', url: string },
    costPoints: number,
    metrics?: Record<string, unknown>
  }>;
}
