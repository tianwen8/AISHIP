# AI 视频 SaaS 蓝图（ALL‑IN‑ONE）
**日期**：2025-10-14

> 一站式 AI 广告/短片工厂：默认“一键出片”，需要时切换“节点画布”精修。
> 单内核、双外壳；多供应商路由；预算友好；节点级缓存；模板/子图复用/批量；可免费前端托管。

---

## 0. 执行摘要（Executive Summary）
- **首发主线**：广告/电商/拉新短视频（10–20s，TikTok/Shorts）。
- **引流模板**：AI 动物 / 走秀（吸引社交流量、拉新）。
- **卖点**：一键即用；想控就控；成本护栏（预算档、低清→高清、缓存、失败不扣费、AB 需显式开启）；可插拔节点与供应商。
- **路线图**：
  - **P0（1–2 周）**：一键模板闭环（TikTok 15s）+ Creem→积分 + R2/S3 缓存 + 预算/成本预估 + 基础 SEO
  - **P1（3–6 周）**：节点画布/子图/批量 + Analyze.Link(Strict) + Publish(YT/TikTok 草稿) + SSE/看板
  - **P2（7–12 周）**：数字人节点 + 更多 T2V 供应商 + 试探→固化路由 + 我的最佳模板 + 自动化 SEO
- **部署**：前端 Vercel/CF Pages；BFF 轻逻辑；重算力走外部 API（OpenRouter/Runway/Luma/Pika/TTS…）；R2/S3 存储。

---

## 1. 产品范围与用例（Product Scope）
### 用户路径
**A. 一键流（默认）**
1) 选模板（行业/时长/平台）→ 输入卖点 → 显示“预计积分/时长” → 开始
2) 系统：脚本/分镜（LLM 路由·预算受控）→ 镜头（图/视频）→ TTS → 字幕/包装 → 导出多规格
3) 可选：AB 并发（显式开启）→ 对比候选 → 选最佳 → 发布或下载

**B. 画布流（进阶）**
- 可视化节点（React Flow）：插/删/改/连、参数编辑
- 保存子图/模板；CSV 批量；断点续跑、失败重跑（不二次扣费）

### 节点族谱（摘要）
`SCRIPT.LLM`、`STORYBOARD.LLM`、`T2I.*`、`T2V.RUNWAY|LUMA|PIKA|…`、`TTS.*`、`TIMELINE.BUILD`、`SUBTITLE.GEN`、`EXPORT.*`、`ANALYZE.LINK(Strict|Owner)`、`PUBLISH.YOUTUBE|TIKTOK|INSTAGRAM|FACEBOOK`、（可选）`AVATAR.CLONE.TRAIN`、`AVATAR.TALK`、`LIPSYNC.RETIME`

### 预算与并发
- 档位：cheap / standard / high → 决定 k_max、低清比例、重试次数
- 并发为**可选**：默认单路（试探→固化最佳供应商）；AB 需显式开启。

---

## 2. 架构总览（单内核双外壳）

```
[Next.js 前端 + Tailwind + React Flow]
  A 一键模板（Invisible Graph）
  B 节点画布（Visible Graph）
        │
        ▼
[BFF / API 网关（Next Route Handlers 或 FastAPI）]
  Auth/会员/积分/限流
  Template/Graph/Run/Publish/Billing/SEO
        │
        ▼
[编排引擎 DAG Orchestrator]
  拓扑/并发/断点/重试/幂等/缓存
  预算档(k_max/低清比例/重试) · 试探→固化 · 评分器(rule/vote/ML)
        │
        ▼
[Provider Router（供应商适配器）]
  LLM(OpenRouter) / T2I / T2V(Runway|Luma|Pika) / TTS / 数字人 / 审核
        │
        ▼
[资产与缓存 R2/S3/Supabase]
        │
        ▼
[Postgres]
users/teams/projects/templates/graphs/runs/jobs/artifacts
usage_ledger/billing/audits/consents/publishing_accounts
```

### 逻辑数据流（ASCII）
```
(用户输入/Analyze.Link) ─▶ [Template API] ─▶ (实例化 Invisible Graph)
                                   │
                                   ▼
                         [Orchestrator 执行]
                  ┌─────────────┬─────────────┬─────────────┐
                  ▼             ▼             ▼
            [LLM Router]   [T2I/T2V]      [TTS/Music]
                  │             │             │
                  └─────▶ 产物缓存(R2/S3) ◀───┘
                                   │
                                   ▼
                             [Timeline/Export]
                                   │
                                   ▼
                               [Publish.*]
```

---

## 3. 前端 ASCII 线框图（布局 & 逻辑）

### 3.1 一键页面（/create）
```
┌───────────────────────────────────────────────────────────────────────┐
│  顶部导航：Logo | Templates | Pricing | Blog | Dashboard | Sign In     │
├───────────────────────────────────────────────────────────────────────┤
│ 左侧配置                                                          30% │
│ ┌───────────────────────────────────────────────────────────────┐     │
│ │ 平台: TikTok / Shorts                                          │     │
│ │ 时长: 15s                                                      │     │
│ │ 行业: 电子产品                                                 │     │
│ │ 卖点/脚本要求: [ 多行文本输入 ]                               │     │
│ │ 预算档: (●standard ○cheap ○high)  预计: 52积分 / 70秒         │     │
│ │ [开始生成] [开启AB(可选)]                                      │     │
│ └───────────────────────────────────────────────────────────────┘     │
│                                                                       │
│ 中央预览区                                                      50%   │
│ ┌───────────────────────────────────────────────────────────────┐     │
│ │ 预览播放器(低清)  | 时间线(镜头/字幕/音乐条)                   │     │
│ │ 事件日志(SSE): 节点状态、耗时、扣费                           │     │
│ └───────────────────────────────────────────────────────────────┘     │
│                                                                       │
│ 右侧候选/产物                                                     20% │
│ ┌───────────────────────────────────────────────────────────────┐     │
│ │ 候选(AB): 方案A / 方案B / ...                                  │     │
│ │ [选为最终] [导出1080x1920] [发布]                              │     │
│ └───────────────────────────────────────────────────────────────┘     │
└───────────────────────────────────────────────────────────────────────┘
```

### 3.2 画布页面（/editor）
```
┌───────────────────────────────────────────────────────────────────────┐
│ 顶部：项目名 | 保存 | 版本/快照 | 运行 | 预算档 | 用量 | 导出          │
├───────────────┬──────────────────────────────────────────┬─────────────┤
│ 左侧节点库    │         画布(React Flow, 网格 + 小地图)  │ 参数检查器  │
│ [文本/分镜]   │  ┌────────────────────────────────────┐  │ [节点表单] │
│ [T2I/T2V/TTS] │  │ n1 SCRIPT  →  n2 STORYBOARD       │  │ [缓存开关] │
│ [Timeline]    │  │     ╲            ╲                 │  │ [锁定/复用]│
│ [Publish]     │  │      n3 T2I       n4 TTS           │  │             │
│ [Analyze]     │  │        ╲            ╲             │  │             │
│ [Avatar]      │  │         n5 TIMELINE → n6 EXPORT    │  │             │
│               │  └────────────────────────────────────┘  │             │
└───────────────┴──────────────────────────────────────────┴─────────────┘
```

### 3.3 仪表盘（/dashboard）
```
[余额/积分][本月用量][最近成片][我收藏的模板][队列进度]
```

---

## 4. 数据与 API（摘要）
### 4.1 表结构（Postgres 摘要）
- users/teams/team_members；projects/templates/graphs；runs/jobs/artifacts；usage_ledger/billing_payments；consents；publishing_*

### 4.2 OpenAPI（摘要）
- `POST /v1/templates/instantiate`
- `POST /v1/runs` · `GET /v1/runs/:id/events` · `GET /v1/runs/:id/artifacts`
- `GET /v1/billing/credits` · `POST /v1/billing/creem/webhook`
- `POST /v1/analyze/link`（Strict/Owner）
- `POST /v1/publish`（多平台草稿/发布）

### 4.3 SSE 事件（样例）
```
event: job
data: {{ "runId":"r1","nodeId":"SCRIPT.LLM","status":"running" }}
event: artifact
data: {{ "jobId":"j3","kind":"video","url":"https://..." }}
event: run
data: {{ "runId":"r1","status":"succeeded","costPoints":83 }}
```

### 4.4 Provider 适配器接口（TS 摘要）
```ts
export interface ProviderAdapter {
  call(inputs: Record<string, unknown>, params: Record<string, unknown>, ctx: { signal?: AbortSignal }): Promise<{
    artifact?: { kind: 'video'|'image'|'audio'|'text'|'timeline', url: string, hash?: string, bytes?: number },
    costPoints: number,
    metrics?: Record<string, unknown>
  }>;
}
```

---

## 5. SEO 与信息架构（要点）
- 页面：`/` `/pricing` `/templates` `/templates/tiktok-15s-行业` `/use-cases` `/blog` `/showcase`
- 技术：SSR/ISR、sitemap、robots、canonical、Schema.org（VideoObject/HowTo/Product）、`hreflang`、OG 图模板
- 文案模块：示例视频、脚本样例、时间线截图、步骤、FAQ、相关模板内链

---

## 6. 会员与积分（Pricing & Credits）
- 层级：Free（限时长/上限/水印/禁并发） · Pro（去水印/优先/子图/批量/可 AB） · Team · Enterprise
- 计费：LLM(1k tokens)、TTS(秒)、T2I/T2V(次/秒，低清/高清)
- 预算档位：cheap(1,100%,0) / standard(1,60%,1) / high(2,40%,2)
- 规则：失败不扣费、缓存不扣费、AB 显式开启

---

## 7. 路线图（Roadmap）
- P0：MVP 闭环（见执行摘要）
- P1：画布/复用/批量 + Analyze.Strict + Publish(YT/TikTok 草稿)
- P2：数字人 + 多供应商 + 试探→固化 + 推荐 + 自动化 SEO

---

## 8. 提示词包（Prompts for Agents）
- P0-01：BFF 骨架 + DDL 迁移 + 最小积分预扣/回滚 + 缓存占位
- P0-02：预算与成本预估（提交前弹窗）
- P0-03：模板与 Invisible Graph（TikTok 15s）
- P1-01：画布 & 子图 & CSV 批量
- P1-02：Analyze.Strict & Publish(YT/TikTok 草稿)
- P2-01：多供应商 + 试探→固化（个性化路由）
- P2-02：数字人与授权（水印/存证）

---

## 9. Monorepo 建议目录（ASCII）
```
your-root/
├─ apps/
│  ├─ web/                # Anyship 改造为主站（入口/SEO/模板页/仪表盘/一键/画布）
│  └─ bff/                # Next Route Handlers 或 FastAPI（择一）
├─ packages/
│  ├─ protocol/           # Graph/Node/Artifact/Timeline JSON Schema（前后端共享）
│  ├─ node-registry/      # 前端节点注册（React 组件）
│  └─ provider-adapters/  # 后端供应商适配器（OpenRouter/Runway/Luma/Pika/TTS…）
├─ services/
│  └─ orchestrator/       # 编排引擎（DAG/缓存/预算/评分器/事件）
├─ docs/                  # 本文件与子文档
└─ README.md
```

---

## 10. 使用方式
- 把 **本文件** 放入仓库：`/docs/AI_Video_SaaS_Blueprint.md`；
- 或下载下方压缩包，内含拆分后的 7 份文档，便于按阶段交给 Claude/Copilot 实施。
