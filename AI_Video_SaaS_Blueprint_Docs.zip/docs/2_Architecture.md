# 架构总览（Architecture）

```
[Next.js 前端 + Tailwind + React Flow]
  A 一键模板（Invisible Graph）
  B 节点画布（Visible Graph）
        │
        ▼
[BFF / API 网关]
  Auth/会员/积分/限流
  Template/Graph/Run/Publish/Billing/SEO
        │
        ▼
[编排引擎 DAG]
  拓扑/并发/断点/重试/幂等/缓存
  预算档(k_max/低清比例/重试) · 试探→固化 · 评分器(rule/vote/ML)
        │
        ▼
[Provider Router]
  LLM / T2I / T2V / TTS / 数字人 / 审核
        │
        ▼
[资产与缓存 R2/S3/Supabase]
        │
        ▼
[Postgres]
users/teams/projects/templates/graphs/runs/jobs/artifacts
usage_ledger/billing/audits/consents/publishing_accounts
```

**发布链路**：`PUBLISH.*` 统一接口 → 各平台 OAuth & API 适配（先 YT/TikTok 草稿）
