# 会员订阅与积分（Pricing & Credits）

## 层级
Free（限时长/上限/水印/禁并发） · Pro（去水印/优先/子图/批量/可 AB） · Team · Enterprise

## 计费口径
- LLM：按 1k tokens
- TTS：按秒
- T2I/T2V：按次/秒（区分低清/高清）
- 失败不扣费；缓存不扣费；AB 显式开启

## 预算档位（示例）
| 档位 | k_max | 低清比例 | 重试 |
|---|---:|---:|---:|
| cheap | 1 | 100% | 0 |
| standard | 1 | 60% | 1 |
| high | 2 | 40% | 2 |
