# 产品范围与用例（Product Scope）

## 一键流（默认）
- 选模板 → 输入卖点 → 预算提示 → 开始
- LLM 脚本/分镜 → T2I/T2V 镜头 → TTS → 字幕/包装 → 导出多规格
- 可选 AB 并发（显式开启）→ 对比候选 → 选最佳 → 发布或下载

## 画布流（进阶）
- React Flow 可视化；插/删/改/连；参数编辑
- 子图/模板保存；CSV 批量；断点续跑；失败重跑不扣费

## 节点族谱（摘要）
SCRIPT.LLM / STORYBOARD.LLM / T2I.* / T2V.RUNWAY|LUMA|PIKA / TTS.* / TIMELINE.BUILD / SUBTITLE.GEN / EXPORT.* / ANALYZE.LINK / PUBLISH.* / (可选) AVATAR.* / LIPSYNC.RETIME

## 预算与并发
- 档位：cheap/standard/high → k_max、低清比例、重试次数
- 默认单路（试探→固化最佳供应商），AB 需显式开启。
