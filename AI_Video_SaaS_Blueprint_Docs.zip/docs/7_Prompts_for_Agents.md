# 提示词包（Prompts for Agents）

> 规则：每次只执行一个任务；严格按 /docs 文档；提交前给“可运行步骤”。

## P0-01 · BFF 骨架 + 数据表迁移
实现：/v1/templates/instantiate, /v1/graphs, /v1/runs, /v1/runs/:id/events, /v1/billing/credits, /v1/billing/creem/webhook
- Postgres + Drizzle 迁移
- 最小“积分预扣/回滚”、缓存占位
- 输出：本地运行脚本、seed、curl 示例

## P0-02 · 预算与成本估算
- estimateCost(graph, budgetTier, kMax)；前端提交前弹窗提示
- usage_ledger 预扣与完成结算

## P0-03 · 模板与 Invisible Graph
- templates/tiktok-15s.json；实例化图；运行→SSE→产物

## P1-01 · 画布 & 子图 & 批量
- React Flow 画布；子图保存/复用；CSV 批量；状态上色；失败重跑

## P1-02 · Analyze.Strict & Publish
- 仅解析元数据/字幕→StyleProfile/TimelineSpec
- Publish：YouTube 上传、TikTok 草稿；失败重试

## P2-01 · 供应商扩展 & 试探→固化
- Runway/Luma/Pika 适配器；个性化路由；AB 显式开关

## P2-02 · 数字人与授权
- AVATAR.* / LIPSYNC.RETIME；consents 表与授权上传；默认水印
