# SEO 与信息架构（SEO & IA）

## 页面
/  /pricing  /templates  /templates/tiktok-15s-行业  /use-cases  /blog  /showcase

## 技术
- SSR/ISR、sitemap、robots、canonical
- 结构化数据：VideoObject / HowTo / Product
- 多语言：hreflang；OG 图模板自动生成

## 模板页要点
- 示例视频、脚本样例、时间线截图、步骤、FAQ、相关模板内链
